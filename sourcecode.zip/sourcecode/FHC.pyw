import sys
import subprocess
import importlib
import re
import os
import json
import base64
from urllib.parse import unquote

# ---------- АВТОУСТАНОВКА ----------
REQUIRED_LIBRARIES = {"requests": "requests", "PyQt6": "PyQt6"}

def install_and_restart(pip_name):
    print(f"\n[Установка] Устанавливаю {pip_name}...")
    subprocess.run([sys.executable, "-m", "pip", "install", pip_name], check=True)
    print(f"[Система] {pip_name} установлен. Перезапуск...")
    os.execv(sys.executable, [sys.executable] + sys.argv)

def check_and_install():
    missing = []
    for module_name, pip_name in REQUIRED_LIBRARIES.items():
        try:
            importlib.import_module(module_name)
        except ImportError:
            missing.append(pip_name)
    if missing:
        for pip_name in missing:
            install_and_restart(pip_name)
        sys.exit(0)

check_and_install()

# ---------- ОСНОВНЫЕ ИМПОРТЫ ----------
import requests
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
    QLineEdit, QLabel, QMessageBox, QInputDialog, QDialog,
    QListWidget, QFileDialog, QFrame, QMenu
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSettings, QUrl
from PyQt6.QtGui import QFont, QAction, QDesktopServices

# ---------- ВЕРСИЯ ----------
VERSION = "0.11"
GITHUB_API = "https://api.github.com/repos/nonamedd324-netizen/FHC/releases/latest"
GITHUB_URL = "https://github.com/nonamedd324-netizen/FHC"
TELEGRAM_URL = "https://t.me/fhcproject"
SUPPORT_URL = "https://t.me/fhcsupport"

# ---------- СТИЛИ ----------
DARK_STYLESHEET = """
    QMainWindow, QDialog { background-color: #18191c; }
    QLabel { color: #f0f0f5; font-family: 'Segoe UI', Arial, sans-serif; border: none; }
    QLineEdit {
        background-color: #212226; color: #f0f0f5;
        border: 1px solid #2d2e33; border-radius: 6px;
        padding: 8px; font-size: 13px;
    }
    QLineEdit:focus { border: 1px solid #2481e0; }
    QTableWidget, QListWidget {
        background-color: #212226; color: #f0f0f5;
        border: 1px solid #2d2e33; border-radius: 8px;
        gridline-color: #2d2e33; font-size: 13px;
    }
    QTableWidget::item, QListWidget::item { padding: 6px; }
    QTableWidget::item:selected, QListWidget::item:selected {
        background-color: #2481e0; color: white;
    }
    QHeaderView::section {
        background-color: #1d1e21; color: #878c96;
        padding: 6px; border: none; font-weight: bold;
    }
    QPushButton {
        background-color: #212226; color: #f0f0f5;
        border: 1px solid #2d2e33; border-radius: 6px;
        padding: 10px 20px; font-weight: bold; font-size: 13px;
    }
    QPushButton:hover { background-color: #2a2b30; }
    QPushButton#blueButton {
        background-color: #2481e0; color: white; border: none;
    }
    QPushButton#blueButton:hover { background-color: #1b6ec2; }
    QPushButton#greenButton {
        background-color: #2ecc71; color: white; border: none;
    }
    QPushButton#greenButton:hover { background-color: #27ae60; }
    QPushButton#cancelButton {
        background-color: #313238; color: #f0f0f5;
        border: 1px solid #3d3e45;
    }
    QPushButton#cancelButton:hover { background-color: #3c3d45; }
"""

# ---------- ПЕРЕВОДЫ ----------
STRINGS = {
    "ru": {
        "window_title": f"FHC - Расшифровка Happ Crypt v{VERSION}",
        "settings": "Настройки",
        "connection_decryption": "Расшифровка и импорт",
        "import_rule": "Операции с подписками:",
        "direct_sub": "Извлечь конфиги из прямой подписки",
        "happ_crypt": "Расшифровать Happ Crypt",
        "db_empty": "База данных пуста. Загрузите конфигурации.",
        "db_count": "В архиве сохранено уникальных баз подписок: {} шт.",
        "open_db": "Открыть базу данных",
        "db_empty_btn": "База данных пуста",
        "open_db_title": "Открыть базу данных ({})",
        "import_sub": "Импорт подписки",
        "enter_url": "Укажите URL адрес подписки:",
        "url_error": "Ссылка обязана иметь формат http:// или https://",
        "reading": "Чтение удаленного репозитория...",
        "ready": "Готово.",
        "no_configs_extract": "Не удалось извлечь конфигурации.",
        "choose_config": "Выберите конфигурацию из списка!",
        "copied": "✅ Ссылка успешно скопирована в буфер обмена!",
        "save_success": "Успешно сохранено объектов: {}",
        "save_error": "Не удалось сохранить: {}",
        "warning": "Внимание",
        "error": "Ошибка",
        "success": "Успех",
        "clipboard": "Буфер обмена",
        "subscription_settings": "Настройки подписки",
        "subscription": "Подписка:",
        "configs_found": "Найдено конфигураций:",
        "show_link": "Показать ссылку",
        "save_all": "Сохранить всё в файл",
        "save_one": "Сохранить в файл",
        "cancel": "Отмена",
        "close": "Закрыть",
        "copy_link": "Скопировать ссылку",
        "original_link": "Исходный VPN-линк:",
        "link_title": "Ссылка: {}",
        "db_title": "База данных подписок",
        "db_archive": "Архив импортированных баз данных подписок",
        "url_col": "Ссылка подписки",
        "count_col": "Количество рабочих конфигов",
        "open_selected": "Открыть выбранную",
        "delete_selected": "Удалить из базы",
        "select_record": "Выберите запись для открытия!",
        "select_delete": "Выберите строку для удаления!",
        "update_check": "Проверить обновления",
        "update_available": "Доступно обновление!",
        "new_version": "Версия {} доступна!\nТекущая: {}\n\nОткрыть страницу GitHub?",
        "no_update": "Актуальная версия",
        "latest_version": "✅ Установлена последняя версия {}",
        "no_releases": "Релизов нет",
        "no_releases_msg": "Релизов на GitHub пока нет.\nПосетить страницу проекта?",
        "check_error": "Ошибка проверки",
        "http_error": "Ошибка HTTP",
        "checking": "Проверка обновлений...",
        "russian": "Русский",
        "english": "English",
        "decrypt_title": "Расшифровка Happ Crypt",
        "enter_happ": "Вставьте строку happ://crypt...:",
        "happ_format_error": "Неверный формат. Ожидается happ://crypt...",
        "decrypting": "Расшифровка через API...",
        "decrypt_error": "Ошибка расшифровки.\nПроверьте ссылку и интернет.",
        "social_btn": "🌐 Наши соцсети",
        "github_action": "GitHub",
        "telegram_action": "Telegram канал",
        "support_action": "Поддержка"
    },
    "en": {
        "window_title": f"FHC - Happ Crypt Decryption v{VERSION}",
        "settings": "Settings",
        "connection_decryption": "Decryption & Import",
        "import_rule": "Subscription operations:",
        "direct_sub": "Extract configs from direct subscription",
        "happ_crypt": "Decrypt Happ Crypt",
        "db_empty": "Database is empty. Load configurations.",
        "db_count": "Unique subscription bases stored: {} pcs.",
        "open_db": "Open database",
        "db_empty_btn": "Database empty",
        "open_db_title": "Open database ({})",
        "import_sub": "Import subscription",
        "enter_url": "Enter subscription URL:",
        "url_error": "URL must start with http:// or https://",
        "reading": "Reading remote repository...",
        "ready": "Ready.",
        "no_configs_extract": "Failed to extract configurations.",
        "choose_config": "Select a configuration from the list!",
        "copied": "✅ Link copied to clipboard!",
        "save_success": "Successfully saved: {} objects",
        "save_error": "Failed to save: {}",
        "warning": "Warning",
        "error": "Error",
        "success": "Success",
        "clipboard": "Clipboard",
        "subscription_settings": "Subscription settings",
        "subscription": "Subscription:",
        "configs_found": "Configs found:",
        "show_link": "Show link",
        "save_all": "Save all to file",
        "save_one": "Save to file",
        "cancel": "Cancel",
        "close": "Close",
        "copy_link": "Copy link",
        "original_link": "Original VPN link:",
        "link_title": "Link: {}",
        "db_title": "Subscription database",
        "db_archive": "Archive of imported subscription bases",
        "url_col": "Subscription URL",
        "count_col": "Working configs count",
        "open_selected": "Open selected",
        "delete_selected": "Delete from database",
        "select_record": "Select a record to open!",
        "select_delete": "Select a row to delete!",
        "update_check": "Check for updates",
        "update_available": "Update available!",
        "new_version": "Version {} is available!\nCurrent: {}\n\nOpen GitHub page?",
        "no_update": "Up to date",
        "latest_version": "✅ Latest version {} is installed",
        "no_releases": "No releases",
        "no_releases_msg": "No releases on GitHub yet.\nVisit project page?",
        "check_error": "Check error",
        "http_error": "HTTP error",
        "checking": "Checking for updates...",
        "russian": "Russian",
        "english": "English",
        "decrypt_title": "Decrypt Happ Crypt",
        "enter_happ": "Enter happ://crypt... string:",
        "happ_format_error": "Invalid format. Expected happ://crypt...",
        "decrypting": "Decrypting via API...",
        "decrypt_error": "Decryption failed.\nCheck link and internet.",
        "social_btn": "🌐 Our socials",
        "github_action": "GitHub",
        "telegram_action": "Telegram channel",
        "support_action": "Support"
    }
}

current_lang = "ru"

def tr(key):
    return STRINGS[current_lang].get(key, key)

# ---------- ПОТОКИ ----------
class FetchDirectThread(QThread):
    finished = pyqtSignal(list, str)
    def __init__(self, url):
        super().__init__()
        self.url = url
    def run(self):
        configs = fetch_and_extract_subscription(self.url)
        if configs:
            self.finished.emit(configs, "")
        else:
            self.finished.emit([], tr("no_configs_extract"))

class HappDecryptThread(QThread):
    finished = pyqtSignal(str, str)
    def __init__(self, enc_url):
        super().__init__()
        self.enc_url = enc_url
    def run(self):
        sub_url = decrypt_happ_crypt(self.enc_url)
        if sub_url:
            self.finished.emit(sub_url, "")
        else:
            self.finished.emit("", tr("decrypt_error"))

class HappFetchThread(QThread):
    finished = pyqtSignal(list, str)
    def __init__(self, sub_url):
        super().__init__()
        self.sub_url = sub_url
    def run(self):
        configs = fetch_and_extract_subscription(self.sub_url)
        if configs:
            self.finished.emit(configs, "")
        else:
            self.finished.emit([], tr("no_configs_extract"))

class UpdateCheckThread(QThread):
    finished = pyqtSignal(str, str, int)
    def __init__(self, current_version):
        super().__init__()
        self.current_version = current_version
    def run(self):
        try:
            response = requests.get(GITHUB_API, timeout=10, headers={
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "FHC-UpdateChecker"
            })
            if response.status_code == 200:
                data = response.json()
                latest = data.get("tag_name", "").lstrip("v")
                if not latest:
                    latest = data.get("name", "").lstrip("v")
                if not latest:
                    latest = self.current_version
                self.finished.emit(latest, "", 200)
            elif response.status_code == 403:
                self.finished.emit("", "rate_limit", 403)
            elif response.status_code == 404:
                self.finished.emit("", "no_releases", 404)
            elif response.status_code == 503:
                self.finished.emit("", "server_error", 503)
            else:
                self.finished.emit("", "http_error", response.status_code)
        except requests.exceptions.ConnectionError:
            self.finished.emit("", "connection_error", 0)
        except requests.exceptions.Timeout:
            self.finished.emit("", "timeout", 0)
        except Exception as e:
            self.finished.emit("", str(e), 0)

# ---------- БЕКЕНД ----------
def decrypt_happ_crypt(encrypted_url: str) -> str:
    api_url = "https://unhapp.xyz/api/decrypt"
    payload = {"url": encrypted_url}
    try:
        response = requests.post(api_url, json=payload, headers={"User-Agent": "v2rayN/6.23"}, timeout=10)
        if response.status_code == 200:
            data = response.json()
            return data.get("subscription_url", "")
        else:
            return ""
    except Exception:
        return ""

def extract_configs(text: str) -> list:
    pattern = r'(vless://[^\s\r\n"\']+|vmess://[^\s\r\n"\']+|trojan://[^\s\r\n"\']+)'
    matches = re.findall(pattern, text)
    return list(dict.fromkeys(matches))

def clean_config_name(text: str) -> str:
    text = re.sub(r'[\U0001F1E6-\U0001F1FF]', '', text)
    text = re.sub(r'\b(DE|SE|PL|FI|RU|TR|FR|NL|GB|UK|US|SG|JP|HK|KZ|UA)\b', '', text, flags=re.IGNORECASE)
    text = re.sub(r'^[ \t\-_.]+|\s+$', '', text)
    return text if text else "Без названия"

def get_vmess_name(vmess_b64: str) -> str:
    try:
        raw = vmess_b64[8:]
        missing = len(raw) % 4
        if missing:
            raw += '=' * (4 - missing)
        decoded = base64.b64decode(raw).decode('utf-8')
        data = json.loads(decoded)
        return clean_config_name(data.get("ps", "Без названия"))
    except Exception:
        return "Без названия"

def get_config_name(config_url: str) -> str:
    if config_url.startswith("vmess://"):
        return get_vmess_name(config_url)
    if "#" in config_url:
        parts = config_url.split("#", 1)
        name = parts[1].strip()
        try:
            decoded_name = unquote(name)
            return clean_config_name(decoded_name)
        except Exception:
            return clean_config_name(name)
    return "Без названия"

def decode_base64_safely(b64_string: str) -> str:
    clean = re.sub(r'[^a-zA-Z0-9+/=]', '', b64_string)
    try:
        return base64.b64decode(clean, validate=False).decode('utf-8', errors='ignore')
    except Exception:
        return ""

def fetch_and_extract_subscription(subscription_url: str) -> list:
    try:
        resp = requests.get(subscription_url, headers={"User-Agent": "v2rayN/6.23"}, timeout=15)
        resp.raise_for_status()
        raw_content = resp.text.strip()
        configs = extract_configs(raw_content)
        if configs:
            return configs
        content_type = resp.headers.get("Content-Type", "").lower()
        if "text/plain" in content_type or "application/octet-stream" in content_type:
            decoded = decode_base64_safely(raw_content)
            configs = extract_configs(decoded)
            if configs:
                return configs
        if not ("<html" in raw_content.lower() or "<!doctype html" in raw_content.lower()):
            decoded = decode_base64_safely(raw_content)
            configs = extract_configs(decoded)
            if configs:
                return configs
        potential_b64_blocks = re.findall(r'["\']([a-zA-Z0-9+/=]{50,})["\']', raw_content)
        for block in potential_b64_blocks:
            decoded = decode_base64_safely(block)
            configs = extract_configs(decoded)
            if configs:
                return configs
        return []
    except Exception:
        return []

def load_subscriptions_db(filepath="subscriptions.json"):
    if os.path.exists(filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_subscriptions_db(db, filepath="subscriptions.json"):
    try:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(db, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

# ---------- ДИАЛОГИ ----------
class ConfigsDialog(QDialog):
    def __init__(self, parent, url, configs):
        super().__init__(parent)
        self.url = url
        self.configs = configs
        self.init_ui()
    def init_ui(self):
        self.setWindowTitle(tr("subscription_settings"))
        self.resize(620, 450)
        layout = QVBoxLayout()
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)
        info_label = QLabel(f"<b>{tr('subscription')}</b> <span style='color: #878c96;'>{self.url}</span><br><b>{tr('configs_found')}</b> {len(self.configs)}")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        self.list_widget = QListWidget()
        for cfg in self.configs:
            self.list_widget.addItem(get_config_name(cfg))
        layout.addWidget(self.list_widget)
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)
        btn_view_link = QPushButton(tr("show_link"))
        btn_view_link.clicked.connect(self.view_selected_link)
        btn_save_all = QPushButton(tr("save_all"))
        btn_save_all.setObjectName("greenButton")
        btn_save_all.clicked.connect(self.save_all_configs)
        btn_close = QPushButton(tr("close"))
        btn_close.setObjectName("cancelButton")
        btn_close.clicked.connect(self.accept)
        btn_layout.addWidget(btn_view_link)
        btn_layout.addWidget(btn_save_all)
        btn_layout.addWidget(btn_close)
        layout.addLayout(btn_layout)
        self.setLayout(layout)
    def view_selected_link(self):
        current_row = self.list_widget.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, tr("warning"), tr("choose_config"))
            return
        full_link = self.configs[current_row]
        name = get_config_name(full_link)
        msg = QDialog(self)
        msg.setWindowTitle(tr("link_title").format(name))
        msg.setMinimumWidth(550)
        vbox = QVBoxLayout()
        vbox.setContentsMargins(15, 15, 15, 15)
        vbox.setSpacing(12)
        edit = QLineEdit(full_link)
        edit.setReadOnly(True)
        vbox.addWidget(QLabel(tr("original_link")))
        vbox.addWidget(edit)
        actions_layout = QHBoxLayout()
        actions_layout.setSpacing(10)
        btn_copy = QPushButton(tr("copy_link"))
        btn_copy.setObjectName("blueButton")
        btn_copy.clicked.connect(lambda: self.copy_to_clipboard(full_link, msg))
        btn_save_one = QPushButton(tr("save_one"))
        btn_save_one.clicked.connect(lambda: self.export_to_file([full_link]))
        btn_hide = QPushButton(tr("close"))
        btn_hide.setObjectName("cancelButton")
        btn_hide.clicked.connect(msg.accept)
        actions_layout.addWidget(btn_copy)
        actions_layout.addWidget(btn_save_one)
        actions_layout.addWidget(btn_hide)
        vbox.addLayout(actions_layout)
        msg.setLayout(vbox)
        msg.exec()
    def copy_to_clipboard(self, text, dialog_context):
        QApplication.clipboard().setText(text)
        QMessageBox.information(dialog_context, tr("clipboard"), tr("copied"))
    def save_all_configs(self):
        self.export_to_file(self.configs)
    def export_to_file(self, links_list):
        path, _ = QFileDialog.getSaveFileName(self, tr("save_all"), "configs.txt", "Text Files (*.txt)")
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write("\n".join(links_list))
                QMessageBox.information(self, tr("success"), tr("save_success").format(len(links_list)))
            except Exception as e:
                QMessageBox.critical(self, tr("error"), tr("save_error").format(e))

class DatabaseDialog(QDialog):
    def __init__(self, parent, subscriptions_db):
        super().__init__(parent)
        self.subscriptions = subscriptions_db
        self.parent = parent
        self.init_ui()
    def init_ui(self):
        self.setWindowTitle(tr("db_title"))
        self.resize(750, 450)
        layout = QVBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)
        layout.addWidget(QLabel(f"<b>{tr('db_archive')}</b>"))
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels([tr("url_col"), tr("count_col")])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.doubleClicked.connect(self.open_selected)
        layout.addWidget(self.table)
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)
        btn_open = QPushButton(tr("open_selected"))
        btn_open.setObjectName("blueButton")
        btn_open.clicked.connect(self.open_selected)
        btn_delete = QPushButton(tr("delete_selected"))
        btn_delete.setObjectName("cancelButton")
        btn_delete.clicked.connect(self.delete_selected)
        btn_close = QPushButton(tr("close"))
        btn_close.clicked.connect(self.accept)
        btn_layout.addWidget(btn_open)
        btn_layout.addWidget(btn_delete)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_close)
        layout.addLayout(btn_layout)
        self.setLayout(layout)
        self.update_table()
    def update_table(self):
        self.table.setRowCount(0)
        for url, configs in self.subscriptions.items():
            row_idx = self.table.rowCount()
            self.table.insertRow(row_idx)
            short_url = url if len(url) < 70 else url[:67] + "..."
            url_item = QTableWidgetItem(short_url)
            url_item.setData(Qt.ItemDataRole.UserRole, url)
            count_item = QTableWidgetItem(f"{len(configs)} шт.")
            count_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(row_idx, 0, url_item)
            self.table.setItem(row_idx, 1, count_item)
    def open_selected(self):
        current_row = self.table.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, tr("warning"), tr("select_record"))
            return
        original_url = self.table.item(current_row, 0).data(Qt.ItemDataRole.UserRole)
        configs = self.subscriptions[original_url]
        dialog = ConfigsDialog(self, original_url, configs)
        dialog.exec()
    def delete_selected(self):
        current_row = self.table.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, tr("warning"), tr("select_delete"))
            return
        original_url = self.table.item(current_row, 0).data(Qt.ItemDataRole.UserRole)
        del self.subscriptions[original_url]
        self.update_table()
        self.parent.update_status()
        save_subscriptions_db(self.subscriptions)

# ---------- ГЛАВНОЕ ОКНО ----------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        global current_lang
        self.settings = QSettings("FHC", "FHC")
        saved_lang = self.settings.value("language", "ru")
        current_lang = saved_lang
        self.subscriptions = load_subscriptions_db()
        self.init_ui()
        self.update_status()

    def init_ui(self):
        self.setWindowTitle(tr("window_title"))
        self.setFixedSize(600, 520)
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(25, 25, 25, 25)
        main_layout.setSpacing(15)

        top_layout = QHBoxLayout()
        self.title_label = QLabel(tr("settings"))
        self.title_label.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
        top_layout.addWidget(self.title_label)
        top_layout.addStretch()

        # Переключатель языка
        self.lang_container = QFrame()
        self.lang_container.setFixedHeight(40)
        self.lang_container.setStyleSheet("""
            QFrame {
                background-color: #1e1e2e;
                border-radius: 18px;
                border: 1px solid #313244;
            }
        """)
        lang_layout = QHBoxLayout(self.lang_container)
        lang_layout.setContentsMargins(4, 4, 4, 4)
        lang_layout.setSpacing(4)

        self.btn_ru = QPushButton("RU")
        self.btn_ru.setFixedSize(55, 30)
        self.btn_ru.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_ru.clicked.connect(lambda: self.set_language("ru"))
        lang_layout.addWidget(self.btn_ru)

        self.btn_en = QPushButton("EN")
        self.btn_en.setFixedSize(55, 30)
        self.btn_en.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_en.clicked.connect(lambda: self.set_language("en"))
        lang_layout.addWidget(self.btn_en)

        top_layout.addWidget(self.lang_container)

        # Кнопка обновления
        self.update_btn = QPushButton(tr("update_check"))
        self.update_btn.setObjectName("blueButton")
        self.update_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.update_btn.clicked.connect(self.check_for_updates)
        top_layout.addWidget(self.update_btn)

        main_layout.addLayout(top_layout)

        self.subtitle_label = QLabel(tr("connection_decryption"))
        self.subtitle_label.setStyleSheet("color: #878c96; font-size: 13px; font-weight: bold; margin-top: 5px;")
        main_layout.addWidget(self.subtitle_label)

        self.card_widget = QWidget()
        self.card_widget.setStyleSheet("background-color: #212226; border: 1px solid #2d2e33; border-radius: 8px; min-width: 500px;")
        card_layout = QVBoxLayout(self.card_widget)
        card_layout.setContentsMargins(20, 15, 20, 15)
        card_layout.setSpacing(10)

        self.import_rule_label = QLabel(f"<span style='color:#878c96;'>{tr('import_rule')}</span>")
        card_layout.addWidget(self.import_rule_label)

        self.btn_add_direct = QPushButton(tr("direct_sub"))
        self.btn_add_direct.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_add_direct.clicked.connect(self.add_direct_subscription)
        card_layout.addWidget(self.btn_add_direct)

        self.btn_decrypt_happ = QPushButton(tr("happ_crypt"))
        self.btn_decrypt_happ.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_decrypt_happ.clicked.connect(self.add_happ_crypt_subscription)
        card_layout.addWidget(self.btn_decrypt_happ)

        main_layout.addWidget(self.card_widget)

        self.btn_db = QPushButton(tr("open_db"))
        self.btn_db.setObjectName("blueButton")
        self.btn_db.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_db.clicked.connect(self.open_database_window)
        main_layout.addWidget(self.btn_db)

        self.status_label = QLabel(tr("db_empty"))
        self.status_label.setStyleSheet("color: #878c96; font-style: italic; font-size: 12px;")
        main_layout.addWidget(self.status_label)

        # Кнопка соцсетей (меню)
        bottom_layout = QHBoxLayout()
        bottom_layout.addStretch()

        self.social_btn = QPushButton(tr("social_btn"))
        self.social_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.social_btn.clicked.connect(self.show_social_menu)
        bottom_layout.addWidget(self.social_btn)

        main_layout.addLayout(bottom_layout)

        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

        self.update_lang_buttons()

    def show_social_menu(self):
        menu = QMenu(self)
        github_action = QAction(tr("github_action"), self)
        github_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl(GITHUB_URL)))
        telegram_action = QAction(tr("telegram_action"), self)
        telegram_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl(TELEGRAM_URL)))
        support_action = QAction(tr("support_action"), self)
        support_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl(SUPPORT_URL)))
        menu.addAction(github_action)
        menu.addAction(telegram_action)
        menu.addAction(support_action)
        menu.exec(self.social_btn.mapToGlobal(self.social_btn.rect().bottomLeft()))

    def set_language(self, lang):
        global current_lang
        if lang != current_lang:
            current_lang = lang
            self.settings.setValue("language", lang)
            self.refresh_ui()
            self.update_lang_buttons()

    def update_lang_buttons(self):
        active_style = """
            QPushButton {
                background-color: #89b4fa;
                color: #1e1e2e;
                border: none;
                border-radius: 14px;
                font-size: 12px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #b4befe;
            }
        """
        inactive_style = """
            QPushButton {
                background-color: transparent;
                color: #cdd6f4;
                border: none;
                border-radius: 14px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #313244;
            }
        """
        if current_lang == "ru":
            self.btn_ru.setStyleSheet(active_style)
            self.btn_en.setStyleSheet(inactive_style)
        else:
            self.btn_ru.setStyleSheet(inactive_style)
            self.btn_en.setStyleSheet(active_style)

    def refresh_ui(self):
        self.setWindowTitle(tr("window_title"))
        self.title_label.setText(tr("settings"))
        self.subtitle_label.setText(tr("connection_decryption"))
        self.import_rule_label.setText(f"<span style='color:#878c96;'>{tr('import_rule')}</span>")
        self.btn_add_direct.setText(tr("direct_sub"))
        self.btn_decrypt_happ.setText(tr("happ_crypt"))
        self.update_btn.setText(tr("update_check"))
        self.social_btn.setText(tr("social_btn"))
        self.update_status()

    def update_status(self):
        count = len(self.subscriptions)
        if count == 0:
            self.status_label.setText(tr("db_empty"))
            self.btn_db.setText(tr("db_empty_btn"))
            self.btn_db.setEnabled(False)
        else:
            self.status_label.setText(tr("db_count").format(count))
            self.btn_db.setText(tr("open_db_title").format(count))
            self.btn_db.setEnabled(True)
        save_subscriptions_db(self.subscriptions)

    def open_database_window(self):
        dialog = DatabaseDialog(self, self.subscriptions)
        dialog.exec()

    def add_direct_subscription(self):
        url, ok = QInputDialog.getText(self, tr("import_sub"), tr("enter_url"))
        if ok and url.strip():
            url = url.strip()
            if not url.startswith(("http://", "https://")):
                QMessageBox.critical(self, tr("error"), tr("url_error"))
                return
            self.status_label.setText(tr("reading"))
            self.set_buttons_enabled(False)
            self.fetch_thread = FetchDirectThread(url)
            self.fetch_thread.finished.connect(self.on_direct_fetched)
            self.fetch_thread.start()

    def on_direct_fetched(self, configs, error_msg):
        self.set_buttons_enabled(True)
        if configs:
            url = self.sender().url
            self.subscriptions[url] = configs
            self.update_status()
            dialog = ConfigsDialog(self, url, configs)
            dialog.exec()
        else:
            QMessageBox.warning(self, tr("warning"), error_msg)
        self.status_label.setText(tr("ready"))

    def add_happ_crypt_subscription(self):
        enc_url, ok = QInputDialog.getText(self, tr("decrypt_title"), tr("enter_happ"))
        if ok and enc_url.strip():
            enc_url = enc_url.strip()
            if not enc_url.startswith("happ://crypt"):
                QMessageBox.critical(self, tr("error"), tr("happ_format_error"))
                return
            self.status_label.setText(tr("decrypting"))
            self.set_buttons_enabled(False)
            self.decrypt_thread = HappDecryptThread(enc_url)
            self.decrypt_thread.finished.connect(self.on_happ_decrypted)
            self.decrypt_thread.start()

    def on_happ_decrypted(self, sub_url, error_msg):
        if not sub_url:
            self.set_buttons_enabled(True)
            QMessageBox.critical(self, tr("error"), error_msg)
            self.status_label.setText(tr("decrypt_error"))
            return
        self.status_label.setText(tr("reading"))
        self.fetch_thread = HappFetchThread(sub_url)
        self.fetch_thread.finished.connect(self.on_happ_fetched)
        self.fetch_thread.start()

    def on_happ_fetched(self, configs, error_msg):
        self.set_buttons_enabled(True)
        if configs:
            sub_url = self.sender().sub_url
            self.subscriptions[sub_url] = configs
            self.update_status()
            dialog = ConfigsDialog(self, sub_url, configs)
            dialog.exec()
        else:
            QMessageBox.warning(self, tr("error"), error_msg)
        self.status_label.setText(tr("ready"))

    def set_buttons_enabled(self, enabled):
        self.btn_add_direct.setEnabled(enabled)
        self.btn_decrypt_happ.setEnabled(enabled)
        self.btn_db.setEnabled(enabled)

    def check_for_updates(self):
        self.status_label.setText(tr("checking"))
        self.update_btn.setEnabled(False)
        self.update_thread = UpdateCheckThread(VERSION)
        self.update_thread.finished.connect(self.on_update_check)
        self.update_thread.start()

    def on_update_check(self, latest_version, error_msg, status_code):
        self.update_btn.setEnabled(True)

        if error_msg == "no_releases":
            reply = QMessageBox.question(
                self,
                tr("no_releases"),
                tr("no_releases_msg"),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                import webbrowser
                webbrowser.open(GITHUB_URL)
            self.status_label.setText(tr("ready"))
        elif error_msg == "rate_limit":
            QMessageBox.warning(self, tr("check_error"), f"GitHub API: Лимит запросов исчерпан (403)\nПопробуйте позже.")
            self.status_label.setText(tr("ready"))
        elif error_msg == "server_error":
            QMessageBox.warning(self, tr("check_error"), f"GitHub сервер временно недоступен (503)\nПопробуйте позже.")
            self.status_label.setText(tr("ready"))
        elif error_msg == "http_error":
            QMessageBox.warning(self, tr("check_error"), f"Ошибка HTTP {status_code}\nНе удалось проверить обновления.")
            self.status_label.setText(tr("ready"))
        elif error_msg == "connection_error":
            QMessageBox.warning(self, tr("check_error"), "Нет подключения к интернету.\nПроверьте соединение.")
            self.status_label.setText(tr("ready"))
        elif error_msg == "timeout":
            QMessageBox.warning(self, tr("check_error"), "Превышено время ожидания.\nПроверьте соединение.")
            self.status_label.setText(tr("ready"))
        elif error_msg == "" and latest_version and latest_version == VERSION:
            QMessageBox.information(self, tr("no_update"), tr("latest_version").format(VERSION))
            self.status_label.setText(tr("ready"))
        elif error_msg == "" and latest_version and latest_version != VERSION:
            reply = QMessageBox.question(
                self,
                tr("update_available"),
                tr("new_version").format(latest_version, VERSION),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                import webbrowser
                webbrowser.open(GITHUB_URL)
            self.status_label.setText(tr("ready"))
        else:
            QMessageBox.warning(self, tr("check_error"), tr("check_error_msg"))
            self.status_label.setText(tr("ready"))

    def closeEvent(self, event):
        save_subscriptions_db(self.subscriptions)
        event.accept()

# ---------- ЗАПУСК ----------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(DARK_STYLESHEET)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())